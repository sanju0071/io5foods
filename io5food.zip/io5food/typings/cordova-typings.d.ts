
/// <reference path="../.vscode/typings/cordova-ionic/plugins/keyboard.d.ts"/>
/// <reference path="../.vscode/typings/jquery/jquery.d.ts"/>